/// Network Images
// ignore: constant_identifier_names
const String NETWORK_IMAGE_POST_PLACEHOLDER =
    "https://socialistmodernism.com/wp-content/uploads/2017/07/placeholder-image.png?w=640";
