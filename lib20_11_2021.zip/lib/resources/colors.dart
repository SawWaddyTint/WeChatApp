import 'package:flutter/material.dart';

const APP_THEME_COLOR = Color.fromRGBO(36, 230, 88, 1.0);
const MOMENTS_BG_COLOR = Color.fromRGBO(243, 243, 243, 1.0);
const CONTACTS_COMMON_COLOR = Color.fromRGBO(227, 228, 231, 1.0);
