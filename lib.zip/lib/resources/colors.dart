import 'package:flutter/material.dart';

const APP_THEME_COLOR = Color.fromRGBO(36, 230, 88, 1.0);
