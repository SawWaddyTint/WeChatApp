import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:we_chat_app/resources/colors.dart';

class MomentsPage extends StatelessWidget {
  const MomentsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 120.0,
        elevation: 0,
        backgroundColor: APP_THEME_COLOR,
        leading: Padding(
          padding: const EdgeInsets.only(left: 14.0),
          child: Row(
            children: [
              Icon(
                Icons.arrow_back_ios,
                size: 20.0,
              ),
              Text(
                "Discover",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w300,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
        title: Text(
          "Moments",
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.search,
              color: Colors.white,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 300.0,
              child: Stack(
                alignment: Alignment.center,
                children: <Widget>[
                  // background image and bottom contents
                  Column(
                    children: <Widget>[
                      Container(
                        height: 200.0,
                        color: Colors.orange,
                        child: Image.network(
                          "https://images.template.net/wp-content/uploads/2014/11/Natural-Facebook-Cover-Photo.jpg",
                          fit: BoxFit.cover,
                        ),
                      ),
                      // Expanded(
                      //   child: Container(
                      //     color: Colors.white,
                      //     child: Center(
                      //       child: Text('Content goes here'),
                      //     ),
                      //   ),
                      // )
                    ],
                  ),
                  Positioned(
                    top: 170.0,
                    right:
                        10.0, // (background container size) - (circle height / 2)
                    child: Text("Waddy"),
                  ),
                  Positioned(
                    top: 220.0,
                    right:
                        10.0, // (background container size) - (circle height / 2)
                    child: Column(
                      children: [
                        Text(
                          "Sunday,Nov 18,2021",
                          style: TextStyle(fontSize: 13.0),
                        ),
                        Text(
                          "23 new moments",
                          style: TextStyle(fontSize: 13.0),
                        ),
                      ],
                    ),
                  ),

                  // Profile image
                  Positioned(
                    top: 150.0,
                    right:
                        200.0, // (background container size) - (circle height / 2)
                    child: Container(
                      height: 80.0,
                      width: 80.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: NetworkImage(
                                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZxkSZZexYAuvoGPFlRyWsZ-XMhaYTDwzk9A&usqp=CAU'),
                          ),
                          shape: BoxShape.circle,
                          color: Colors.green),
                      // child: Image.network(
                      //   "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTmDZqFk24mo_-qNzSjjW_04GrisbLgfqlZMw&usqp=CAU",
                      // ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
